package com.example.app.service;

import java.util.List;

import com.example.app.Employee;

public interface EmployeeService {
	
	List<Employee> getallEmployee();
	
	void saveEmployee(Employee employee);
	
	Employee getEmployeeById(long id);
	
   void deleteEmployeeById(long id);

}
